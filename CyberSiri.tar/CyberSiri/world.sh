#!/bin/bash

#enable multilib in pacman.conf
sudo sed -i '93,94 s/# *//' /etc/pacman.conf
sudo pacman -Syu

#Installing xorg and some fonts.
sudo pacman --noconfirm -S xf86-video-vesa
sudo pacman --noconfirm -S xorg-server  xorg-apps xorg-xinit
sudo pacman --noconfirm -S ttf-dejavu  ttf-droid  ttf-inconsolata terminus-font

#Installing yajl (Yet Another JSON LIBARY) this is needed for yaourt
sudo pacman --noconfirm -S yajl

#Installing yaourt for easy AUR installs
git clone https://aur.archlinux.org/package-query-git.git
cd package-query-git
makepkg -sri --noconfirm
cd ..
git clone https://aur.archlinux.org/yaourt.git
cd yaourt
makepkg -si --noconfirm
cd ..
yaourt -Syu --aur

#Installing i3-gaps + dmenu 
sudo pacman --noconfirm -S i3 i3blocks dmenu
yaourt --noconfirm -S i3-gaps

#Make startx command start i3
echo exec i3 > .xinitrc

#Download Cybersiri theme from git
git clone https://github.com/CyberSiri/i3-CyberSiri.git
cd i3-CyberSiri

#Move stuff to right places
mkdir ~/.config
mkdir ~/.config/i3
cp config ~/.config/i3
cp i3blocks.conf ~/.config/i3
mkdir ~/.fonts
cp fontawesome-webfont.ttf  ~/.fonts
mkdir ~/Images
cp cybersiri.png ~/Images/wallpaper.jpg
cp .Xdefaults ~/.Xdefaults
cd ..

#installing diffrent tools used by CyberSiri Theme
sudo pacman --noconfirm -S rxvt-unicode chromium lm_sensors mps-youtube feh htop youtube-dl mpv pulseaudio pavucontrol pamixer alsa-utils thunar xfce4-screenshooter

#Install virtualbox guest additions
sudo pacman --noconfirm -S virtualbox-guest-utils
sudo pacman --noconfirm -S linux-headers
sudo systemctl enable vboxservice.service

echo  ---------------------------------------------------------------
echo		Reboot and pet your cat and pray that it worked!
echo		      Have fun!, Greetings from CyberSiri
echo  ---------------------------------------------------------------
