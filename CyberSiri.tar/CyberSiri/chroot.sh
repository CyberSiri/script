#!/bin/bash

#Edit this to change your computer name and username
HOST=CyberSiri
USERNAME=siri

HOME_DIR="/home/${USERNAME}"
SWAP_SIZE=4G
echo DISK="$1", HOST="$HOST", USERNAME="$USERNAME", HOME_DIR="$HOME_DIR"
grub-install --target=i386-pc --recheck "$1"
sudo sed -i 's/GRUB_TIMEOUT=5/GRUB_TIMEOUT=0/g' /etc/default/grub
grub-mkconfig -o /boot/grub/grub.cfg
systemctl enable dhcpcd.service
echo "$HOST" > /etc/hostname
useradd -m -G wheel -s /bin/bash "$USERNAME"

#Edit this for your timezone!
ln -f -s /usr/share/zoneinfo/Europe/Helsinki /etc/localtime

hwclock --systohc
echo 'name_servers="8.8.8.8 8.8.4.4"' >> /etc/resolvconf.conf
echo en_US.UTF-8 UTF-8 > /etc/locale.gen
echo LANG=en_US.UTF-8 > /etc/locale.conf
locale-gen
echo 'root ALL=(ALL) ALL' > /etc/sudoers
echo 'siri ALL=(ALL) ALL' >> /etc/sudoers
fallocate -l "$SWAP_SIZE" /swapfile
chmod 600 /swapfile
mkswap /swapfile
echo /swapfile none swap defaults 0 0 >> /etc/fstab
echo complete -cf sudo >> /etc/bash.bashrc
echo complete -cf man >> /etc/bash.bashrc
