#!/bin/bash
DISK="/dev/sda"
PARTITION="${DISK}1"
echo DISK="$DISK", PARTITION="$PARTITION"
parted -s "$DISK" mklabel msdos
parted -s -a optimal "$DISK" mkpart primary ext4 0% 100%
parted -s "$DISK" set 1 boot on
mkfs.ext4 -F "$PARTITION"
echo 'Server = http://ftp.acc.umu.se/mirror/archlinux/$repo/os/$arch' > /etc/pacman.d/mirrorlist
mount "$PARTITION" /mnt
pacman -Syy
pacstrap /mnt  base base-devel grub git 
genfstab -p /mnt >> /mnt/etc/fstab
cp ./chroot.sh /mnt
arch-chroot /mnt ./chroot.sh "$DISK"
rm /mnt/chroot.sh

#Edit this and change to your username (same username you used in chroot.sh)
cp ./world.sh /mnt/home/siri
cp ./.bash_profile /mnt/home/siri

umount -R /mnt
systemctl reboot
